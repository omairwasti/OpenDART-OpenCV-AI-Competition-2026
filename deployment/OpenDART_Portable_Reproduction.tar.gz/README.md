# OpenDART — OpenCV 5 image feedback for bounded autonomous interception

OpenDART is an inspectable research and education demonstrator: rendered camera pixels become OpenCV measurements, an estimated relative state, a bounded guidance action, changed spacecraft geometry and a new image. It helps students and vision/GNC researchers examine what happens when image feedback is useful, missing, biased or uncertain. It is not flight software or a reconstruction of DART's flown autonomy stack.

**[Live synthetic closed loop](http://ec2-54-253-67-121.ap-southeast-2.compute.amazonaws.com/) · [Real DRACO imagery](http://ec2-54-253-67-121.ap-southeast-2.compute.amazonaws.com/draco) · [Final technical report](submission/opendart_2026_final/OpenDART_Technical_Report_Final.pdf)**

![OpenDART architecture](submission/opendart_2026_final/diagrams/overall_system.png)

OpenCV 5 does substantive work: image normalisation, Gaussian filtering, morphological segmentation, connected components, weighted centroid/area extraction, contours and association. The primary competition path is a physical XY-plane scene with PlanarEKF navigation and estimated-state ZEM guidance. Truth supplies rendering and evaluation only; there is no per-frame hidden truth fallback to guidance.

## Results and their limits

- Task 1 synthetic size-measurement calibration (+1.07 px predicted detector-radius offset) reduced one nominal final position error from 59.18 to 9.23 m and peak error from 2097 to 375 m. This is renderer/detector calibration, not DRACO instrument calibration.
- Task 2: 96/96 guided cases reached TARGET_IMPACT across two appearances, 12 seeds and four conditions. Each 12/12 cell has Wilson 95% interval [0.758, 1.000]. These are bounded tested outcomes, not “100% reliable”. All four BALLISTIC/NO_MEASUREMENT controls missed; zero-thrust closest approach was 615.52 m.
- A 40 s blackout was followed by an accepted update at 240 s in all tested extended-blackout cases. Full-state covariance showed substantial undercoverage: no statistical EKF-consistency claim is made.
- On 18 reviewed of 20 sampled held-out DRACO frames, the separate frozen autonomous method matched 6/8 compact points within 5 px (available-point median 1.218 px, n=6) and had median visible-region IoU 0.802, n=8. Two unreviewed boundary cases were excluded; there are no reviewed labels in the final ten seconds.
- The AWS application executes genuine OpenCV 5 workloads. The real-image analyzer processes a chosen original frame afresh from validated past-only state. Recorded DRACO images cannot respond to new commands and do not validate real guidance.

## Quick start — no DRACO download needed

Use Python 3.12 and one OpenCV wheel variant. From the runnable code root:

```powershell
python -m venv .venv
.venv/Scripts/Activate.ps1
python -m pip install -r submission/opendart_2026_final/requirements-local-py312.txt
python -m pip install --no-deps -e .
python -c "import cv2; print(cv2.__version__); assert cv2.__version__ == '5.0.0'"
python -m opendart.visual --config configs/visual_2d.json --out results/MY_NEW_VISUAL
python -m pytest -q -ra --basetemp=results/MY_NEW_TEST_TMP
```

Use a fresh output directory. Linux activation is `source .venv/bin/activate`; the Linux deployment pins include Gunicorn. Open `results/MY_NEW_VISUAL/index.html` or its MP4. The rendered/reference-texture scene remains synthetic, not historical flight reconstruction.

## Reproduction and evidence

See the [submission package](submission/opendart_2026_final/README.md), [reproduction instructions](submission/opendart_2026_final/REPRODUCTION.md), [claims and limits](submission/opendart_2026_final/CLAIMS_AND_LIMITATIONS.md), and [AWS judge walkthrough](submission/opendart_2026_final/AWS_DEMO.md). Historical derivations and controller treatment remain in the technical report.

The main assumptions are known physical target radius, a bounded planar scene, prescribed ephemeris, known camera geometry and simplified attitude/actuation. Covariance undercoverage and transient radius-prior bias remain limitations. There is no crater/deflection or post-contact model. No new research/tuning is part of the final package.

## Historical and supporting work

The original 3D restricted-binary dynamics, PD/ZEM controllers, 6.1 km/s impact-like example and geometric BearingEKF support the project but are not the same scenario as the primary 20 m/s visual demonstration. Their equations are retained in the final report. Supporting guides remain in `docs/TECHNICAL_submission/opendart_2026_final/OpenDART_Technical_Report_Final.pdf.md`, `docs/VISUAL_SIMULATION.md` and `docs/VISION_INTEGRATION.md`; early-stage future-work statements there are historical. Python is canonical. MATLAB sources are retained for comparison; full MATLAB runtime validation is not claimed.

```powershell
python -m opendart.cli --config configs/fast_terminal.json --out results/MY_NEW_3D
python -m opendart.cli --config configs/synthetic_bearings.json --out results/MY_NEW_BEARINGS
```

The project combines synthetic causal control evidence with a separate historical-image perception study. The scope and limitations are documented in the report.
