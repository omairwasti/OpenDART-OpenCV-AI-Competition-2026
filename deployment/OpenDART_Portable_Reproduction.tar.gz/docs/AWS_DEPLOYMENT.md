# OpenDART Task 3A deployment

This is a bounded synthetic planar OpenCV 5 demonstrator. The web adapter calls
`simulate_planar` without changing its detector, association, EKF, guidance or
plant. Known target size supplies monocular scale. Task 2 showed empirical
covariance undercoverage; contact does not establish estimator consistency.
This is not a reconstruction/validation of the real DART mission or a flight-ready system.

## Deployment scope

One CloudFormation stack in `ap-southeast-2` owns one private encrypted S3 bucket,
one HTTP-only security group, one EC2 role/profile, and one `c7i-flex.large`
Ubuntu 24.04 x86_64 instance. EC2 owns its encrypted 20 GiB gp3 root disk and
ephemeral public IPv4. Existing default VPC/subnet/routes are reused.
Only port 80 is public. Gunicorn binds `127.0.0.1:8000`; SSM provides administration.
No SSH keys or local AWS credentials are deployed. IMDSv2 is mandatory;
the unprivileged application service is denied access to the metadata IP.
The endpoint is HTTP: use public demo inputs only. Stop/start changes its address.

## Local gate and build

From the package root, using the OpenDART Python 3.12 environment:

```powershell
python -m pip install Flask==3.1.3
python -m pytest -q -ra --basetemp=results/NEW_RUN/test_tmp
python -m opendart.web_runner --preset NOMINAL --out results/NEW_RUN/nominal
python -m opendart.web_runner --preset NO_MEASUREMENT --out results/NEW_RUN/no_measurement
./deploy/aws/package.ps1 -Python python -OutputDirectory results/NEW_RUN/bundle
```

Use fresh result directories. The release builder verifies Task 2's frozen
scientific hashes (excluding the approved `pyproject.toml` web metadata change).
It only includes selected source/config/test files, deployment files, one small
bundled PNG and curated evidence. It never traverses raw campaigns, `.aws`,
environments, FITS or PDS archives. SHA-256 manifests contain relative paths.

## Two-phase CloudFormation

```powershell
./deploy/aws/deploy.ps1 -Phase Prepare -ReleaseMetadata results/NEW_RUN/bundle/release.json -EvidenceDirectory results/NEW_RUN/aws
# Poll CREATE_COMPLETE before continuing.
./deploy/aws/deploy.ps1 -Phase Compute -ReleaseMetadata results/NEW_RUN/bundle/release.json -EvidenceDirectory results/NEW_RUN/aws
```

`Prepare` re-resolves and verifies Canonical's public Ubuntu 24.04 AMI, checks the
instance offering and price guardrail, and creates the bucket, role/profile and
security group. `Compute` uploads checksum-addressed release/manifest objects,
then enables the single instance. Do not repeat creation if the selected instance
is blocked: inspect/report account restrictions instead. Do not change instance type
without measured need and approval.

CloudFormation completion does not establish application readiness. Inspect SSM
and `/var/log/cloud-init-output.log`. Bootstrap installs binary-pinned Linux
dependencies, verifies one OpenCV distribution/runtime, runs `pip check` and the
full test suite, and only then starts the app and Nginx. Logs and JUnit output are
under `/var/lib/opendart/validation`. Stop and report scientific Linux failures.

## Execution limits and verification

Exactly NOMINAL, BLACKOUT, NO_MEASUREMENT and BALLISTIC are exposed, seed 7.
NOMINAL retains the shipped `[200,220)` s blackout; BLACKOUT uses `[200,240)` s.
An OS file lock shared by server/worker admits one simulation globally. Jobs have
a 180-second subprocess timeout (also an independent Linux worker alarm), one
OpenCV/BLAS thread, a 3 GiB systemd application-tree memory ceiling, bounded
512×512 inputs and no public numerical parameters. The one Gunicorn worker uses
four HTTP threads. Nginx limits submission/read requests; the application permits
20 submissions/hour. Up to 20 job directories and roughly 24-hour/1-GiB retention
are enforced at admission and by five-minute housekeeping. A service restart can
reset the in-memory hourly counter; inputs/concurrency/time/memory remain bounded.

Result PNG overlays are captured sparsely; all simulation image/detector intervals
still execute. No MP4 or per-step visual dashboard is generated. Relative
trajectories distinguish EKF output from evaluation truth. Ground truth is not
fed back to guidance by the adapter. Metrics include update counts, NAV_HOLD,
delta-v, final estimation error, cloud runtime and Linux peak resident memory.

Verify EC2 checks, SSM, RAM/disk baseline, Python/OpenCV, `pip check`, Linux tests
and all four external HTTP jobs. `verify_deployment.py` polls jobs, downloads PNGs
and compares important metrics against `evidence/frozen_seed7.json`. Preserve all
differences; stop on unexplained scientific disagreement, never tune it away.

```powershell
python deploy/aws/verify_deployment.py --endpoint http://PUBLIC_HOST --out results/NEW_RUN/cloud --baseline results/NEW_RUN/frozen_seed7.json
```

The selected local report/plots are identified as Task 2 evidence. Older
uncalibrated videos are excluded. No extra DRACO/PDS data is processed.

## Costs, rollback and cleanup

At the approved October 2026 rates, `c7i-flex.large` plus 20 GiB gp3 and one public
IPv4 is approximately US$2.84/day or US$19.88/week, before tax, traffic, S3 and any
credits. Credits are not assumed. The deployment driver rejects EC2 prices above
US$0.12/hour. There are no commitments, load balancers or NAT gateways.

Failed bootstrap remains observable through SSM; do not bypass failed science
tests. Previous immutable releases can be selected through an explicit SSM
rollback after stopping the application. Validate before reopening Nginx.

The initial bootstrap exposed an unavailable Ubuntu `awscli` apt package. The
corrected template installs AWS CLI v2 from AWS's official Linux x86_64 installer.
`repair-bootstrap.ps1` supports a reviewed CloudFormation change set that refuses
any change except a non-replacing modification of `Compute`, then resumes that
exact instance's updated user-data script through SSM. EBS-backed user-data
updates restart the instance and can change its ephemeral public address.
No second instance or public SSH is required.

Cleanup is deliberately not run during deployment:

```powershell
./deploy/aws/cleanup.ps1 -StackName opendart-task3a -Region ap-southeast-2
# Optional export of selected known jobs before deletion:
./deploy/aws/cleanup.ps1 -StackName opendart-task3a -Region ap-southeast-2 -ExportDirectory results/NEW_EXPORT -JobIds JOB_ID_1,JOB_ID_2
```

The script validates the stack tag/resource types and obtains the exact owned
bucket before emptying it. It deletes that stack and checks the instance, root
EBS, network interface/public IP association, group, role/profile and bucket.
It leaves the existing VPC/network infrastructure untouched. Stopping alone is
not cleanup and continues to incur storage charges.
